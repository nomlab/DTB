require 'webrick'
require 'webrick/httpproxy'
require 'uri'
require 'lib/referer_filter'
require 'lib/windows'

=begin
def init
  tmp = WindowsLibs.make_path(["public", "images", "tmp"])
  WindowsLibs.delete_directory(tmp)
  `mkdir #{tmp}`
end
=end

# 2分おきに「計算機外部の履歴情報」を取得
# 取得したデータのURLはlib\tmpurl.txtに保存する
# 取得したデータのサムネイルはpublic\images\tmp\以下に保存する
def get_history
  # カウントの初期化
  # 仕事の開始と終了までの間にデスクトップブックマークをシャットダウンしたときのための処理
  count = 0
  tmp_dir = WindowsLibs.make_path(["public", "images", "tmp"])
  WindowsLibs.ls(tmp_dir).each do |f|
    count = WindowsLibs.start_count(f, count)
  end

  # 計算機外部の履歴情報取得部
  Thread.new do
    history_old = []
    while true
      plogfile = WindowsLibs.make_path(["lib", "PrivateServerLog.txt"])
      history = selection_data(referer_filter(plogfile), 0.0)
      sleep 60
      (history - history_old).each do |line|
        thumbnail_path = WindowsLibs.make_path(["public", "images", "tmp", "thumbnail#{count}.jpg"])
        WindowsLibs.screen_capture(thumbnail_path, line)

        info = count.to_s + "__" + line + "\n"
        tmpurl = WindowsLibs.make_path(["lib", "tmpurl.txt"])
        open(tmpurl, 'a+') do |f|
          f.puts info
        end
        count += 1
      end
      history_old = history
    end
  end
end

# 計算機のスクリーンショットの取得部
# 利用者をいらいらさせるため，保留
=begin
# 30秒おきに「計算機内部の履歴情報」を取得
# 定数の設定
gw_OWNER     = 4
gw_HWNDFIRST = 0
gw_HWNDLAST  = 1
gw_HWNDNEXT  = 2
gw_HWNDPREV  = 3
ws_EX_APPWINDOW = 0x00040000
ws_EX_TOOLWINDOW = 0x00000080
old_hWnd = 0
ap_count = 0
liber = WindowsLibs.new
Thread.new do
  while true
    sleep 30
    hWnd = LibAPI.getForegroundWindow()
    if hWnd != old_hWnd
      # ウィンドウハンドルの拡張ウィンドウハンドルを取得
      lExStyle = LibAPI.getWindowLongA(hWnd, (-20))
      # 最小化されているAPは表示
      if (lExStyle & ws_EX_APPWINDOW) == ws_EX_APPWINDOW
        liber.screen_capture("public\\images\\tmp\\apthumb#{ap_count}", "", hWnd)
        tmp = "#{ap_count}" + "___" + liber.get_exefile(hWnd)
        `ruby lib\\catstr.rb \"#{tmp}\" >> lib\\tmpap.txt`
        ap_count += 1
        old_hWnd = hWnd
      # タスクバー上のAPは非表示
      elsif (lExStyle & ws_EX_TOOLWINDOW) == ws_EX_TOOLWINDOW
        ;
      # 通常のAPは以下の条件を満たすもののみ表示
      else
        # 親ウィンドウが存在する
        if LibAPI.getWindow(hWnd, gw_OWNER) == 0
          # ウィンドウが表示されている状態である
          if LibAPI.isWindowVisible(hWnd) != 0
            hParent = LibAPI.getParent(hWnd)
            # オーナーウィンドウがない，もしくはデスクトップと同じ
            if hParent == 0 or hParent == LibAPI.getDesktopWindow()
              liber.screen_capture("public\\images\\tmp\\apthumb#{ap_count}", "", hWnd)
              tmp = "#{ap_count}" + "___" + liber.get_exefile(hWnd)
              `ruby lib\\catstr.rb \"#{tmp}\" >> lib\\tmpap.txt`
              ap_count += 1
              old_hWnd = hWnd
            end
          end
        end
      end
    end
  end
end
=end
# 計算機のスクリーンショットの取得部 ここまで

# ログファイルの設定(出力同期モードを真に)
filename = WindowsLibs.make_path(["lib", "PrivateServerLog.txt"])
accesslog = File.open(filename, "w")
accesslog.sync = true

# Private Proxy Server の設定
config = {
  :BindAddress => '127.0.0.1', # バインドアドレス(デフォルト:nil)
  :Port => 8080,               # ポート番号(デフォルト:80)
  #:Logger => WEBrick::Log::new($stdout, WEBrick::Log::DEBUG),  # ログファイルの種類と出力先(デフォルト:nil)
  :AccessLog => [              # アクセスログの形式と出力先(デフォルト:長くなるので省略)
    #[ $stdout, "%h %l %u %t \"%r\" %s %b\n%{Referer}i -> %U" ]
    [ accesslog, "%t \"%{Content-Type}o\" %s %b\n%{Referer}i -> %U" ]
  ],
  :ProxyVia => false           # proxy が通ってきたことを header で報せるか(デフォルト:true)
  #:ProxyURI => URI.parse('http://localhost:3128/')            # 親プロキシ(デフォルト:nil)
}

# プロキシサーバオブジェクトを作る
s = WEBrick::HTTPProxyServer.new(config)
#s = PrivateProxyServer.new(config)

# SIGINT を捕捉する。
Signal.trap('INT') do
  # 捕捉した場合、シャットダウンする。
  s.shutdown
end

# サーバを起動する
#init
get_history
s.start

# 終了処理
accesslog.close
