class CreateZimbras < ActiveRecord::Migration
  def self.up
    create_table :zimbras do |t|
      t.string :server
      t.string :username
      t.string :password
      t.boolean :used

      t.timestamps
    end
  end

  def self.down
    drop_table :zimbras
  end
end
