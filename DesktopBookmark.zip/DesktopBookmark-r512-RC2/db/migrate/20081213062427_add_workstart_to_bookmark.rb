class AddWorkstartToBookmark < ActiveRecord::Migration
  def self.up
    add_column :bookmarks, :workstart, :datetime
  end

  def self.down
    remove_column :bookmarks, :workstart
  end
end
