class CreateHistoryInMachines < ActiveRecord::Migration
  def self.up
    create_table :history_in_machines do |t|
      t.column :path,       :string
      t.column :title,      :string
      t.column :thumbnail,  :string
      t.column :flag,       :boolean
      t.column :created_on, :datetime
      t.column :updated_on, :datetime
    end
  end

  def self.down
    drop_table :history_in_machines
  end
end
