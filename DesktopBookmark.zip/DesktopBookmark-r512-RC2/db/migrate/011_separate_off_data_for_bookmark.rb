class SeparateOffDataForBookmark < ActiveRecord::Migration
  def self.up
    bookmarks = Bookmark.find :all
    bookmarks.each do |bookmark|
      if bookmark.data != nil
        history_i = bookmark.data.split(/\n/)
        history_i.each do |line|
          if line =~ /(\d\d\d\d\/\d\d\/\d\d \d\d:\d\d) ([\S ]*)(\tstar)?$/
            time = $1
            path = $2
            flag = $3
            history = HistoryInMachine.new

            if $3 != nil
              history.flag = true
            else
              history.flag = false
            end

            history.path = path
            history.save
            HistoryInMachineBookmark.create(:history_in_machine => history, :bookmark => bookmark)
          end
        end
      end

      if bookmark.url != nil
        history_o = bookmark.url.split(/\n/)
        filename = bookmark.created_on.strftime("%Y-%m-%d-%H")
        history_o.each do |line|
          if line =~ /(\d+?)__(.+?)$/
            history = HistoryOutOfMachine.new
            count = $1
            url   = $2

            history.thumbnail = "#{filename}\\thumbnail#{count}.jpg"
            history.url = url
            history.save
            HistoryOutOfMachineBookmark.create(:history_out_of_machine => history, :bookmark => bookmark)
          end
        end
      end
    end
    remove_column :bookmarks, :repository
    remove_column :bookmarks, :data
    remove_column :bookmarks, :url
  end

  def self.down
    add_column :bookmarks, :repository, :text
    add_column :bookmarks, :data, :text
    add_column :bookmarks, :url, :text
    bookmarks = Bookmark.find :all
    bookmarks.each do |bookmark|
      t = bookmark.created_on.strftime("%Y/%m/%d %H:%M")
      bookmark.data = ""
      bookmark.url  = ""

      history_i_array = bookmark.history_in_machines
      history_i_array.each do |history|
        if history.flag
          bookmark.data << (t + " " + history.path + "\tstar")
        else
          bookmark.data << (t + " " + history.path)
        end
        HistoryInMachineBookmark.delete_all(["history_in_machine_id = ?", history])
        history.destroy
      end

      history_o_array = bookmark.history_out_of_machines
      history_o_array.each do |history|
        if history.thumbnail =~ /.*(\d+)\.jpg/
          bookmark.url << ($1 + "__" + history.url + "\n")
        end
        HistoryOutOfMachineBookmark.delete_all(["history_out_of_machine_id = ?", history])
        history.destroy
      end

      bookmark.save
    end
  end
end
