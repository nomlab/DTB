class CreateExticons < ActiveRecord::Migration
  def self.up
    create_table :exticons do |t|
      t.column :ext,        :string
      t.column :created_on, :datetime
      t.column :updated_on, :datetime
    end
  end

  def self.down
    drop_table :exticons
  end
end
