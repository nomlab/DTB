class CreateHistoryOutOfMachines < ActiveRecord::Migration
  def self.up
    create_table :history_out_of_machines do |t|
      t.column :url,        :string
      t.column :title,      :string
      t.column :thumbnail,  :string
      t.column :created_on, :datetime
      t.column :updated_on, :datetime
    end
  end

  def self.down
    drop_table :history_out_of_machines
  end
end
