class CreateBookmarks < ActiveRecord::Migration
  def self.up
    create_table :bookmarks do |t|
      t.column :work,       :text
      t.column :keyword,    :text
      t.column :comment,    :text
      t.column :data,       :text
      t.column :url,        :text
      t.column :updated_on, :datetime
      t.column :created_on, :datetime
    end
  end

  def self.down
    drop_table :bookmarks
  end
end
