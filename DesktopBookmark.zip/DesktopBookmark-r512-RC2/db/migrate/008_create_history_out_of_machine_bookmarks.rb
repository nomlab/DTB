class CreateHistoryOutOfMachineBookmarks < ActiveRecord::Migration
  def self.up
    create_table :history_out_of_machine_bookmarks do |t|
      t.column :history_out_of_machine_id, :integer
      t.column :bookmark_id,               :integer
    end
  end

  def self.down
    drop_table :history_out_of_machine_bookmarks
  end
end
