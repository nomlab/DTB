class CreateRepositoryStateBookmarks < ActiveRecord::Migration
  def self.up
    create_table :repository_state_bookmarks do |t|
      t.column :repository_state_id,   :integer
      t.column :bookmark_id,           :integer
    end
  end

  def self.down
    drop_table :repository_state_bookmarks
  end
end
