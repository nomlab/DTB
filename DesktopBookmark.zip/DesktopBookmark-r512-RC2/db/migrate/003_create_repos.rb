class CreateRepos < ActiveRecord::Migration
  def self.up
    create_table :repos do |t|
      t.column :name,       :string
      t.column :path,       :string
      t.column :updated_on, :datetime
      t.column :created_on, :datetime
    end
  end

  def self.down
    drop_table :repos
  end
end
