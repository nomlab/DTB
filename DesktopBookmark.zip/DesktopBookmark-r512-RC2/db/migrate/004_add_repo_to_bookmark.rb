class AddRepoToBookmark < ActiveRecord::Migration
  def self.up
    add_column :bookmarks, :repository, :text
  end

  def self.down
    remove_column :bookmarks, :repository
  end
end
