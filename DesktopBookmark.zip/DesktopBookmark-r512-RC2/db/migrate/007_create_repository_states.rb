class CreateRepositoryStates < ActiveRecord::Migration
  def self.up
    create_table :repository_states do |t|
      t.column :repo_id,    :integer
      t.column :revision,   :integer
      t.column :created_on, :datetime
      t.column :updated_on, :datetime
    end
  end

  def self.down
    drop_table :repository_states
  end
end
