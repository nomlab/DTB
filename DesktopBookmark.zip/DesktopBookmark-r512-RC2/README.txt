﻿□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□

  デスクトップブックマーク - Ver.0.52                        2009/01/28
                                          岡山大学 大学院自然科学研究科
                                                             乃村研究室
                                                              小笠原 良
                                     ogasawara@swlab.cs.okayama-u.ac.jp
                      http://www.swlab.cs.okayama-u.ac.jp/%7Eogasawara/

□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□

■Desktop Bookmarkについて

デスクトップブックマークは計算機上で仕事を行っている際の仕事状態(起動し
ていたAPと参照していたデータ)を復元するソフトウェアです．本ソフトウェア
の機能は以下の通りです．

  (1) 仕事開始時から終了時までに参照した文書ファイル履歴の保存
  (2) 仕事開始時から終了時までに参照したWebページ履歴の保存
  (3) 保存した情報の閲覧
  (4) 仕事状態保存時に開いていたAP,および参照していたデータの一括再参照

■動作環境

以下のOSで動作を確認しています．

  (1) Microsoft Windows XP 
  (2) Microsoft Windows Vista (Business)

■はじめての方へ

(1) 以下のURLからzipファイルをダウンロードして下さい．
  http://tsubame.swlab.cs.okayama-u.ac.jp/~ogasawara/desktop_bookmark/download/ruby-1.8.7.zip
  http://tsubame.swlab.cs.okayama-u.ac.jp/~ogasawara/desktop_bookmark/download/0.5/DesktopBookmark.exe

(2) ruby-1.8.7.zipファイルを"C:\"以下に解凍してください．

(3) 環境変数PATHに以下のパスを追加してください．
  C:\ruby-1.8.7\bin

  Windowsの場合，環境変数の変更方法は以下の通りです．
    (A) コントロールパネルからシステムのプロパティを開く．
    (B) 詳細設定タブの環境変数ボタンから変数PATHの編集ボタンをクリック 
        する．
    (C) 既存のパスの右端に以下を追記する．(はじめのセミコロンを忘れない
        ようにして下さい)
      ;C:\ruby-1.8.7\bin

(4) DesktopBookmark.exeを起動し，指示に従ってインストールしてください．
    (Windows Vistaの場合は，管理者権限で実行してください)

(5) 以下のURLにアクセスすると，インストールは完了です．
  http://localhost:3000/desktop_bookmark/init

■旧バージョンのデスクトップブックマークをインストール済みの方へ

(1) 以下のURLから最新バージョンのzipファイルをダウンロードして下さい．
  http://tsubame.swlab.cs.okayama-u.ac.jp/~ogasawara/desktop_bookmark/download/0.5/DesktopBookmark.exe

(2) ダウンロードしたzipファイルを任意のフォルダに解凍してください．

(3) 以下のコマンドを実行してください
  > gem update --system
  > gem install rails --version=2.1.1
  > gem install mongrel mongrel_service win32-shortcut will_paginate

(4) 旧バージョンのデスクトップブックマークから以下の情報をコピーしてください．
  (A) $(DTBroot)\config\database.yml
  (B) $(DTBroot)\public\images 以下
  (C) $(DTBroot)\db\*.sqlite3 (production.sqlite3と改名してコピー)

(5) コマンドプロンプトから以下のコマンドを実行して下さい．(Windows 
    Vistaの場合は，管理者権限で実行してください)
  > ruby install.rb

(6) 以下のURLにアクセスすると，インストールは完了です．
  http://localhost:3000/desktop_bookmark/init

■現在開発中のデスクトップブックマークを使いたい方へ

デスクトップブックマークの開発版はSubversionのリポジトリからチェックア
ウトすることで利用可能になります．利用方法は以下の通りです

(1) TortoiseSVN 1.4X をインストール(日本語化ツールあり)します．以下の
    Webページを参考にして下さい．
  http://www.gside.org/Gentoo/subversion/subversion_client.html

(2) 以下のアドレスより，デスクトップブックマークをチェックアウトできま 
    す．
  http://tsubame.swlab.cs.okayama-u.ac.jp/svn/lastnote/experimentals/DesktopBookmark
  ID   : lastnote
  Pass : muraosa

(3) DesktopBookmark.exeを起動し，指示に従ってインストールしてください．
    (Windows Vistaの場合は，管理者権限で実行してください)

(4) 以下のURLにアクセスすると，インストールは完了です．
  http://localhost:3000/desktop_bookmark/init

■使用方法

8080番ポートでhttpプロキシサーバが起動しています．デスクトップブック
マークはhttpプロキシサーバを介して通信を行ったWebブラウザの履歴を保存す
るので，Webブラウザのプロキシサーバの設定を「http://localhost:8080/」に
してください．

◎firefoxのアドオンPrefBarを導入すると，プロキシサーバの切り替えが容易
になりますので，利用してみてください．

デスクトップブックマークはWebインタフェースとなっています．デスクトップ
ブックマークを利用するには，Webブラウザで以下のURLにアクセスしてくださ
い．

http://localhost:3000/desktop_bookmark

(1) 仕事の開始時に「仕事の開始ボタン」をクリックすると，履歴情報の収集 
    を開始します．

(2) 仕事の終了時に「仕事状態の保存ボタン」クリックすると，収集した履歴 
    情報を仕事状態として保存します．

(3) 仕事を再開したい場合，仕事状態のリストの中から，再開したい仕事を選 
    択すると，仕事状態の詳細を閲覧できます．

(4) 仕事状態の詳細画面から，再参照したいデータを選択すると，データに関 
    連付けられたAPでデータを参照できます．

(5) Webブラウザの設定でJavascriptを有効にしている場合，「デスクトップ復
    元」ボタンをクリックすると，その仕事に関連のあるデータを一括で再参 
    照します．

■ファイルとAPの関連付けについて

デスクトップブックマークは保存した仕事状態のデータをクリックすると，
データの拡張子に関連付けられたAPで参照するようになっています．このデー
タの拡張子とAPとの関連付けは，エクスプローラのツール -> フォルダオプシ
ョンの「ファイルの種類」タグから変更可能です．

■アンインストール

「プログラムの追加と削除」より，「デスクトップブックマーク RC2」を選択
し，アンインストールしてください．

■Subversionとの連携

Subversionと連携させることで，どのバージョンに戻せばいいか簡単に分かります．

(1) Subversionのインストール方法

Subversion (subversion.tigris.org)の Downloadsのページに行くと，ファイ
ルの一覧が出るので，新しいものを選んでダウンロードしてください．

http://subversion.tigris.org/servlets/ProjectDocumentList?folderID=91

ダウンロードしたファイルを実行するとインストールが始まります．

(2) デスクトップブックマークへの登録

デスクトップブックマークトップページより，「リポジトリの編集」リンク
をクリックすると，リポジトリの登録画面に遷移します．ここから，自分の
ローカルで利用しているリポジトリのワーキングコピーのパスを入力してくだ
さい．

(3) SSHを利用する場合

PuTTYごった煮版をインストール．
PuTTYをインストールしたディレクトリへのパスを通す
puttygen.exeで公開鍵と秘密鍵を作成．
秘密鍵は，秘密鍵の作成から．公開鍵はテキストをドキュメントファイルにコ
ピーアンドペースト
C:\Documents And Setting\[[user]]\Application Data\Subversion\config
(C:\Users\[[user]]\AppData\Roaming\Subversion\config(Windows Vista))
の[tunnels]に以下を追加する
ssh = plink.exe
pageant.exeを起動する

■更新履歴
ver.0.5 Rails2.1.1に対応，インストール方法の変更
ver.0.4 インタフェースの改善
ver.0.3 Subversionとの連携機能を追加
ver.0.2 バグフィックス
ver.0.1 バグフィックス
ver.0.0 機能を公開しました．バグは沢山あって見づらいと思いますが，使っ
        ていただけたら幸いです．よろしくお願いします．
