require 'rubygems'
require 'win32/service'
require 'win32/shortcut'
require 'Win32API'
require 'win32ole'
require 'nkf'
include Win32

if Service.exists?("DesktopBookmark")
  Service.stop "DesktopBookmark" rescue nil
  Service.delete "DesktopBookmark"
end

obj1 = Win32API.new 'shell32', 'SHGetFolderPath', %w(l l l l p), 'l'
    
# スタートアップフォルダの特定
strBuff = "\0" * 200
obj1.call(0, 7, 0, 0, strBuff)
startup_path = strBuff.split(/\0/)[0]

File.delete(startup_path + "\\PrivateProxyServer.lnk") rescue nil
File.delete(startup_path + "\\DesktopBookmark.lnk") rescue nil

wsh = WIN32OLE.new('WScript.Shell')
wsh.Popup(NKF.nkf("-s", "デスクトップブックマークをアンインストールしました"),0,NKF.nkf("-w", "確認"))
