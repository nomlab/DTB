# 標準出力で与えられた文字列をそのまま返す
puts ARGV.shift
