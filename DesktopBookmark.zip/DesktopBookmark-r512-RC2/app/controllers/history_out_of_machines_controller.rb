class HistoryOutOfMachinesController < ApplicationController
  require_dependency 'lib/windows'

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  #verify :method => :post, :only => [ :destroy, :create ],
  #       :redirect_to => { :action => :list }

  # GET /dtb/:dtb_id/web_history
  # GET /dtb/:dtb_id/web_history.xml
  def show
    @bookmark = Bookmark.find params[:dtb_id]

    respond_to do |format|
      format.html # index.rhtml
      format.xml { render :xml => @bookmark.history_out_of_machines }
    end
  end

  # GET /dtb/:dtb_id/web_history/new
  # GET /dtb/:dtb_id/web_history/new.xml
  def new
    @bookmark = params[:dtb_id]
  end

  # POST /dtb/:dtb_id/web_history
  # POST /dtb/:dtb_id/web_history.xml
  def create
    bookmark = Bookmark.find(params[:dtb_id])
    HistoryOutOfMachine.new_from_historystring(params[:history][:url], bookmark)
    flash[:notice] = '計算機内部の履歴情報を追加しました'
    redirect_to :action => 'show', :dtb_id => params[:dtb_id]
  end

  # GET /dtb/:dtb_id/web_history/edit
  def edit
    @bookmark = Bookmark.find params[:dtb_id]
  end

  # PUT /dtb/:dtb_id/web_history
  # PUT /dtb/:dtb_id/web_history.xml
  def update
    respond_to do |format|
      (params[:histories] || []).each do |h|
        HistoryOutOfMachine.find(h.to_i).destroy
      end

      flash[:notice] = '計算機外部の履歴情報を更新しました.'
      format.html { redirect_to dtb_path(params[:dtb_id])}
      format.xml  { head :ok}
    end
  end

=begin
  # DELETE /dtb/:dtb_id/web_history
  # DELETE /dtb/:dtb_id/web_history.xml
  def destroy
    HistoryOutOfMachine.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
=end
end
