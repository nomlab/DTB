class ZimbraController < ApplicationController
  def index
    list
    render :action => 'list'
  end

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  verify :method => :post, :only => [ :destroy, :create, :update ],
         :redirect_to => { :action => :list }

  def list
    @zimbra = Zimbra.find :all
  end

  def show
    @zimbra = Zimbra.find(params[:id])
  end

  def new
    @zimbra = Zimbra.new
  end

  def create
    @zimbra = Zimbra.new(params[:zimbra])
    if @zimbra.save
      flash[:notice] = 'Zimbra was successfully created.'
      redirect_to :action => 'list'
    else
      render :action => 'new'
    end
  end

  def edit
    @zimbra = Zimbra.find(params[:id])
  end

  def update
    @zimbra = Zimbra.find(params[:id])
    if @zimbra.update_attributes(params[:zimbra])
      flash[:notice] = 'Zimbra was successfully updated.'
      redirect_to :action => 'show', :id => @zimbra
    else
      render :action => 'edit'
    end
  end

  def destroy
    Zimbra.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
end
