class DesktopBookmarkController < ApplicationController
  require_dependency 'lib/windows'
  require 'nkf'
  require 'will_paginate'

  auto_complete_for :bookmark, :work
  auto_complete_for :bookmark, :keyword

  #verify :method =>:post, :only => [ :destroy, :create, :update ],
  #       :redirect_to => { :action =>:list }

  # GET /dtb/init
  def init
    set_job_start_time()
    set_tmpurl_file()
    #check_repository()

    if params[:id]
      redirect_to :action => 'show', :id => params[:id]
    else
      redirect_to :action => 'index' 
    end
  end

  # GET /dtb
  # GET /dtb.xml
  def index
    @bookmarks = Bookmark.paginate(:page => params[:page], :per_page => 8, :order => "id DESC")

    respond_to do |format|
      format.html # index.html.erb
      format.xml { render :xml => @bookmarks }
    end
  end

  # GET /dtb/:id
  # GET /dtb/:id.xml
  def show
    @bookmark = Bookmark.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml { render :xml => @bookmark }
    end
  end

  # GET /dtb/new
  # GET /dtb/new.xml
  def new
    @bookmark = Bookmark.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml { render :xml => @bookmark }
    end
  end

  # GET /dtb/:id/edit
  def edit
    @bookmark = Bookmark.find(params[:id])
  end

  # POST /dtb
  # POST /dtb.xml
  def create
    time = Time.new
    filename = time.strftime("%Y%m%d%H%M")
    `mkdir #{WindowsLibs.make_path(["public", "images", filename])}`

    @bookmark = Bookmark.new(params[:bookmark])
    @bookmark.updated_on = time
   #@bookmark.apexe = history_ap(filename)
 
    timefile = WindowsLibs.make_path(["lib", "start_time.txt"])
    open(timefile) do |f|
      time = f.gets.split "-"
      @bookmark.workstart = Time.mktime *time
    end

    respond_to do |format|
      if @bookmark.save
        history_in_machine(@bookmark)
        history_out_of_machine(@bookmark, filename)
        get_repository_number(@bookmark)
        to_zimbra(@bookmark)

        flash[:notice] = '仕事状態の作成に成功しました'
        format.html{ redirect_to(:action => 'init', :id => @bookmark) }
        format.xml { render :xml => @bookmark, :status => :created, :location => @bookmark }
      else
        flash[:notice] = '仕事状態の作成に失敗しました'
        format.html{ render :action => 'new' }
        format.xml { render :xml => @bookmark.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /dtb/:id
  # PUT /dtb/:id.xml
  def update
    @bookmark = Bookmark.find(params[:id])
    respond_to do |format|
      if @bookmark.update_attributes(params[:bookmark])
        flash[:notice] = 'Comment was successfully updated.'
        format.html { redirect_to( :action => 'show', :id => @bookmark) }
        format.xml  { head :ok }
      else
        format.html { render :action => 'edit' }
        format.xml  { render :xml => @person.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /dtb/:id
  # DELETE /dtb/:id.xml
  def destroy
    bookmark = Bookmark.find(params[:id])
    if bookmark.history_out_of_machines != []
      filename = bookmark.history_out_of_machines.first.thumbnail.split("\\")[0]
      thumbnail_path = WindowsLibs.make_path(["public", "images", filename])
      WindowsLibs.delete_directory(thumbnail_path)
    end
    bookmark.destroy

    respond_to do |format|
      format.html { redirect_to(:action => 'index') }
      format.xml  { head :ok }
    end
  end

  # GET /dtb/discover
  def discover
    @bookmarks = Bookmark.searched_for_work(params[:bookmark][:work])
    if @bookmarks
      respond_to do |format|
        format.html { render :action => "list", :id => @bookmarks }
        format.xml  { render :xml => @bookmarks }
      end
    else
      flash[:notice] = 'そんなBookmarkは存在しません.'
      redirect_to :action => 'index'
    end
  end

  # GET /dtb/restore
  def restore
    id = NKF.nkf("-s", params[:id])
    if params[:format]
      filename = "tmp.#{params[:format]}"
      path = WindowsLibs.make_path(["tmp", filename])
      `svn export #{id}.#{params[:format]} #{path} -r #{params[:num]}`
    else
      filename = "tmp.txt"
      path = WindowsLibs.make_path(["tmp", filename])
      `svn cat #{id} > #{path} -r #{params[:num]}`
    end

    send_file("./tmp/#{filename}")
  end

  # GET /dtb/:id/phoenix
  def phoenix
    bookmark = Bookmark.find(params[:id])
    historys = bookmark.history_in_machines
    historys.each do |history|
      #if history.flag
        WindowsLibs.restore_ap(history.path, false)
      #end
    end
    redirect_to :action => 'show', :id => params[:id]
  end

=begin
  def startap
    Thread.new do
      linkpath = "\"" + params[:id] + "\""
      path = NKF.nkf('-s', linkpath)
      system(path)
    end

    redirect_to :action => 'show', :id => params[:page]
  end

  def auto_complete_for_bookmark_work
    roma = NKF.nkf("-w", params[:bookmark][:work].to_s)
    @bookmarks = Bookmark.find(:all, :conditions=>["work LIKE ?", '%' + roma + '%'])
    render :partial => "keyword"
  end

  def discover_keyword
    @bookmarks = Bookmark.searched_for_keyword(params[:bookmark][:keyword])
    if @bookmarks
      render :action => "list", :id => @bookmarks
    else
      flash[:notice] = 'そんなBookmarkは存在しません.'
      redirect_to :action => 'index'
     end
  end

  def auto_complete_for_bookmark_keyword
    roma = NKF.nkf("-w", params[:bookmark][:keyword].to_s)
    @bookmarks = Bookmark.find(:all, :conditions=>["keyword LIKE ?", '%' + roma + '%'])
    render :partial => "keyword"
  end
=end

  ################################################################
  #
  # 以下，private メソッド
  #
  ################################################################
  private 
  # 仕事開始時間を設定するメソッド
  def set_job_start_time
    job_start_time = Time.new
    timefile = WindowsLibs.make_path ["lib", "start_time.txt"]
    open(timefile, "w") do |f|
      f.puts job_start_time.strftime("%Y-%m-%d-%H-%M-%S")
    end
  end

  # サムネイルを保存するディレクトリを新規作成するメソッド
  def set_tmpurl_file
    src = WindowsLibs.make_path(["lib", "nil.txt"])
    dst = WindowsLibs.make_path(["lib", "tmpurl.txt"])
    WindowsLibs.copy(src, dst)

    tmp = WindowsLibs.make_path(["public", "images", "tmp"])
    WindowsLibs.delete_directory(tmp)
    `mkdir #{tmp}`
  end

  # リポジトリ内部のパス移動をチェックするメソッド
  def check_repository
    logarray = []
    Repo.find(:all).each do |r|
      rs = RepositoryState.find(:all, :order => "created_on DESC", :conditions => ["repo_id == ?", r.id])[0]
      logmsg = `start /b /d \"#{r.path}\" svn log --verbose -r #{rs.revision}:HEAD`
      logmsg.each do |line|
        if line =~ /^   A (.*?) \((.*?):\d*/
          p1 = $1
          p2 = $2
          n_path = (r.path + p1).gsub!(/\//, "\\")
          o_path = (r.path + p2).gsub!(/\//, "\\")
          hs = HistoryInMachine.find(:all)
          if hs != []
            hs.each do |h|
              if h.path != nil
                if h.path.downcase == o_path.downcase
                  h.path = n_path
                  h.save
                end
              end
            end
          end
        end
      end
    end
  end

  # 起動時と現在の「最近開いたファイル」情報を比較した結果を返すメソッド
  def compare_file_access_log(bookmark)
    job_start_time = ""
    timefile = WindowsLibs.make_path(["lib", "start_time.txt"])
    open(timefile) do |f|
      time = f.gets.split "-"
      job_start_time = Time.mktime *time
    end

    array = WindowsLibs.get_lnk(job_start_time)
    flag = false

    repos = Repo.find(:all) 
    for r in repos
      flag = false
      #`start /b /d \"#{r.path}\" svn update`
      logmsg = `start /b /d \"#{r.path}\" svn stat`

      logmsg.each do |line|
        if line =~ /^\s*?A\s*(.*)/ or line =~ /^\s*?M\s*(.*)/
          # array << ("0000/00/00 00:00 " + WindowsLibs.make_path([r.path, $1]))
          array << WindowsLibs.make_path([r.path, $1])
          flag = true
        end
      end

      if flag
        `start /b /d \"#{r.path}\" svn commit -m \"DTB:#{NKF.nkf("-s", bookmark.work)}\"`
        `start /b /d \"#{r.path}\" svn update`
      end
    end

    return array.uniq
  end

  # 現在起動しているAPの実行パスを返すメソッド
  def exec_ap
    ap_array = []
    Hash[*WindowsLibs.get_task].each do |hWnd, ap_exefile|
      ap_array = ap_array + [ap_exefile]
    end

    # 重複要素を除外
    return ap_array.uniq
  end

  # 計算機内部の履歴情報を保存するメソッド
  def history_in_machine(bookmark)
    recent_file = compare_file_access_log(bookmark)
    ap_array = exec_ap()


    recent_file.each do |line|
      #if line =~ /(\d\d\d\d\/\d\d\/\d\d \d\d:\d\d) ([\S ]*)/
        history = HistoryInMachine.new
        path = NKF.nkf "-w", line

        # pathと関連付けられているAP
        rexe = WindowsLibs.associate(path)
        if ap_array.include?(rexe)
          history.flag = true
        else
          history.flag = false
        end

        history.path = path
        history.save
        HistoryInMachineBookmark.create(:history_in_machine => history, :bookmark => bookmark)
      #end
    end
  end

  # 計算機外部の履歴情報を保存するメソッド
  def history_out_of_machine(bookmark, filename)
    cat = WindowsLibs.make_path(["lib", "cat.rb"])
    tmpurl = WindowsLibs.make_path(["lib","tmpurl.txt"])
    historyarray = `ruby #{cat} #{tmpurl}`.split(/\n/)

    HistoryOutOfMachine.new_from_historyarray(historyarray, filename, bookmark)
  end

  # リポジトリの状態を取得するメソッド
  def get_repository_number(bookmark)
    repository = ""
    repos = Repo.find(:all) 
    for repo in repos
      `start /b /d \"#{repo.path}\" svn up`
      svn_info = `start /b /d \"#{repo.path}\" svn info`
      if svn_info != nil
        status = RepositoryState.new
        status.repo_id = repo.id

        tmp =  NKF.nkf "-wS", svn_info
        a = tmp.split(/\n/)
        a.each do |line|
          if line =~ /リビジョン.*?(\d+)/
            number = $1
            status.revision = number.to_i
          end 
        end 
        status.save
        RepositoryStateBookmark.create(:repository_state => status, :bookmark => bookmark)
      end
    end
  end

=begin
  def history_ap(filename)
    # 現在までに起動していたAPの実行パス
    array = []
    i = 0
    cat = WindowsLibs.make_path(["lib", "cat.rb"])
    tmpap = WindowsLibs.make_path(["lib","tmpap.txt"])
    `ruby #{cat} #{tmpap}`.each do |line|
      if /^(\d*)___(.*)$/ =~ line
        ap_count = $1
        path     = $2
        src = WindowsLibs.make_path(["public", "images", "tmp", "apthumb#{ap_count}.jpg"])
        dst = WindowsLibs.make_path(["public", "images", filename, "#{i+1}.jpg"])
        WindowsLibs.copy(src, dst)
        array = array +  [path]
        i += 1
      end
    end
    ap_array2.join(", ")
  end
=end

  def to_zimbra(bookmark)
    File.open("template.ics", "w") do |file|
      icsdata = <<-ICS
BEGIN:VCALENDAR
PRODID:-//NOMURA Mahito//Manually//EN
METHOD:PUBLISH
VERSION:2.0
BEGIN:VTIMEZONE
TZID:Japan
BEGIN:STANDARD
DTSTART:19390101T000000
TZOFFSETFROM:+0900
TZOFFSETTO:+0900
TZNAME:JST
END:STANDARD
END:VTIMEZONE
BEGIN:VEVENT
CONTACT:http://localhost:3000/dtb/#{bookmark.id.to_s}
DTSTART;TZID=Japan:#{(bookmark.workstart).strftime("%Y%m%dT%H%M%S")}
DTEND;TZID=Japan:#{bookmark.created_on.strftime("%Y%m%dT%H%M%S")}
SUMMARY:#{bookmark.work}
DESCRIPTION:デスクトップブックマークの仕事状態ですhttp://localhost:3000/dtb/#{bookmark.id.to_s}
CLASS:PRIVATE
END:VEVENT
END:VCALENDAR
      ICS
      icsdata.each do |line|
        file.puts line
      end
    end

    Zimbra.find(:all, :conditions => ["used == ?", true]).each do |zimbra|
      command = "lib\\curl-7.10.8-win32-ssl\\curl.exe -u #{zimbra.username}:#{zimbra.password} --data-binary @template.ics http://#{zimbra.server}/service/home/#{zimbra.username}/calendar?fmt=ics"
      `#{command}`
    end
  end
end
