class RepositoryController < ApplicationController
  require 'will_paginate'

  def index
    list
    render :action => 'list'
  end

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  verify :method => :post, :only => [ :destroy, :create, :update ],
         :redirect_to => { :action => :list }

  def list
    @repo = Repo.paginate(:page => params[:page], :per_page => 7, :order => "id DESC")
  end

  def show
    @repo = Repo.find(params[:id])
  end

  def new
    @repo = Repo.new
  end

  def create
    @repo = Repo.new(params[:repo])
    if @repo.save
      flash[:notice] = 'Repo was successfully created.'
      redirect_to :action => 'list'
    else
      render :action => 'new'
    end
  end

  def edit
    @repo = Repo.find(params[:id])
  end

  def update
    @repo = Repo.find(params[:id])
    if @repo.update_attributes(params[:repo])
      flash[:notice] = 'Repo was successfully updated.'
      redirect_to :action => 'show', :id => @repo
    else
      render :action => 'edit'
    end
  end

  def destroy
    Repo.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
end
