class HistoryInMachinesController < ApplicationController
  require_dependency 'lib/windows'

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  #verify :method => :post, :only => [ :destroy, :create ],
  #       :redirect_to => { :action => :list }

  # GET /dtb/:dtb_id/file_history
  # GET /dtb/:dtb_id/file_history.xml
  def show
    @bookmark = Bookmark.find params[:dtb_id]

    respond_to do |format|
      format.html # index.rhtml
      format.xml { render :xml => @bookmark.history_in_machines }
    end
  end

  # GET /dtb/:dtb_id/file_history/new
  # GET /dtb/:dtb_id/file_history/new.xml
  def new
    @bookmark = params[:dtb_id]
  end

  # POST /dtb/:dtb_id/file_history
  # POST /dtb/:dtb_id/file_history.xml
  def create
    @history = HistoryInMachine.new(params[:history])
    @history.flag = false
    if @history.save
      HistoryInMachineBookmark.create(:history_in_machine => @history, :bookmark => Bookmark.find(params[:dtb_id]))
      flash[:notice] = '計算機内部の履歴情報を更新しました'
      redirect_to :action => 'show', :dtb_id => params[:dtb_id]
    else
      render :action => 'new'
    end
  end

  # GET /dtb/:dtb_id/file_history/edit
  def edit
    @bookmark = Bookmark.find params[:dtb_id]
  end

  # PUT /dtb/:dtb_id/file_history
  # PUT /dtb/:dtb_id/file_history.xml
  def update
    respond_to do |format|
      (params[:histories] || []).each do |h|
        HistoryInMachine.find(h.to_i).destroy
      end

      flash[:notice] = '計算機内部の履歴情報を更新しました.'
      format.html { redirect_to dtb_path(params[:dtb_id])}
      format.xml  { head :ok}
    end
  end

=begin
  # DELETE /dtb/:dtb_id/file_history
  # DELETE /dtb/:dtb_id/file_history.xml
  def destroy
    HistoryInMachine.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
=end

  # GET /file_history/:id/link
  def link
    path = HistoryInMachine.find(params[:id]).path
    WindowsLibs.restore_ap(path, params[:format])

    redirect_to dtb_path(params[:page])
  end
end
