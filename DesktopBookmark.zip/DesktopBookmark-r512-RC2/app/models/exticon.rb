class Exticon < ActiveRecord::Base
end
