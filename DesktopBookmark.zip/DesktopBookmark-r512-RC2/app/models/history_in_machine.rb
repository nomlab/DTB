class HistoryInMachine < ActiveRecord::Base
  has_many :history_in_machine_bookmarks, :dependent => :destroy
  has_many :bookmarks, :through => :history_in_machine_bookmarks
end
