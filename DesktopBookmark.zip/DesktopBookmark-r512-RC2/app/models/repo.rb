class Repo < ActiveRecord::Base
  has_many :repository_states, :dependent => :destroy
end
