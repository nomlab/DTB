class HistoryOutOfMachine < ActiveRecord::Base
  has_many :history_out_of_machine_bookmarks, :dependent => :destroy
  has_many :bookmarks, :through => :history_out_of_machine_bookmarks

  require_dependency 'lib/windows'

  def self.new_from_historystring(str, bookmark)
    history = self.new

    filename = bookmark.created_on.strftime("%Y%m%d%H%M")
    count = 0
    tmp_dir = WindowsLibs.make_path(["public", "images", filename])
    WindowsLibs.ls(tmp_dir).each do |f|
      count = WindowsLibs.start_count(f, count)
    end
    thumbnail_path = WindowsLibs.make_path(["public", "images", filename, "thumbnail#{count}.jpg"])

    WindowsLibs.screen_capture(thumbnail_path, str)
    history.thumbnail = WindowsLibs.make_path([filename, "thumbnail#{count}.jpg"])
    history.url = str
    history.save
    HistoryOutOfMachineBookmark.create(:history_out_of_machine => history, :bookmark => bookmark)
  end

  def self.new_from_historyarray(array, filename, bookmark)
    i = 0

    array.each do |line|
      if /^(\d*)__(.*?)$/ =~ line
        history = self.new
        count = $1
        url   = $2

        src = WindowsLibs.make_path(["public", "images", "tmp", "thumbnail#{count}.jpg"])
        dst = WindowsLibs.make_path(["public", "images", filename, "thumbnail#{i}.jpg"])
        WindowsLibs.copy(src, dst)
        history.thumbnail = WindowsLibs.make_path([filename, "thumbnail#{i}.jpg"])
        history.url = url
        history.save
        HistoryOutOfMachineBookmark.create(:history_out_of_machine => history, :bookmark => bookmark)

        i += 1
      end
    end
  end
end
