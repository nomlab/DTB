class HistoryOutOfMachineBookmark < ActiveRecord::Base
  belongs_to :history_out_of_machine
  belongs_to :bookmark
end
