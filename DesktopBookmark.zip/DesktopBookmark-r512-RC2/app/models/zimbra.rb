class Zimbra < ActiveRecord::Base
end
