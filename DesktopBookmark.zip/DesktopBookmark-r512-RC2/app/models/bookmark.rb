class Bookmark < ActiveRecord::Base
  has_many :history_in_machine_bookmarks, :dependent => :destroy
  has_many :history_in_machines, :through => :history_in_machine_bookmarks, :dependent => :destroy
  has_many :history_out_of_machine_bookmarks, :dependent => :destroy
  has_many :history_out_of_machines, :through => :history_out_of_machine_bookmarks, :dependent => :destroy
  has_many :repository_state_bookmarks, :dependent => :destroy
  has_many :repository_states, :through => :repository_state_bookmarks, :dependent => :destroy

  def self.searched_for_work(keyword)
    hit_bookmark = []

    self.find(:all).each do |b|
      if b.work =~ /#{keyword}/
        hit_bookmark << b
      end
    end

    return hit_bookmark
  end

  def self.searched_for_keyword(keyword)
    hit_bookmark = []

    self.find(:all).each do |b|
      if b.keyword =~ /#{keyword}/
        hit_bookmark << b
      end
    end

    return hit_bookmark
  end
end
