class RepositoryStateBookmark < ActiveRecord::Base
  belongs_to :repository_state
  belongs_to :bookmark
end
