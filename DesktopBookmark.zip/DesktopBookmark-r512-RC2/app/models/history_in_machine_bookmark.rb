class HistoryInMachineBookmark < ActiveRecord::Base
  belongs_to :history_in_machine
  belongs_to :bookmark
end
