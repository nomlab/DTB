class RepositoryState < ActiveRecord::Base
  belongs_to :repo
  has_many :repository_state_bookmarks
  has_many :bookmarks, :through => :repository_state_bookmarks
end
