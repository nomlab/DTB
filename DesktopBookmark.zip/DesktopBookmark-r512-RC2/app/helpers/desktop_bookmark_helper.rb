module DesktopBookmarkHelper
  require_dependency 'lib/referer_filter'
  require 'time'
  
  # 状態保存時に起動していたAP
  def getap(bookmark)
    filename = etime(bookmark.created_on)
    array_ap = bookmark.apexe.split(/, /)
    num = 0
    array_ap.map!{ |line|
      num += 1
      line = "<a href = \"/desktop_bookmark/startap/" + line + "?page=" + bookmark.id.to_s + "\">" + "<img src=\"../../images/#{filename}/#{num}.jpg\" alt=\"" + line + "\" title=\"" + line + "\" style=\"margin: 3px; border: 1px solid #606060;\">" + "</a>"
    }
    array_ap.join("")
  end
end
