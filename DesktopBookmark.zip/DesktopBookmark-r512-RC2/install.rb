require 'rubygems'
require 'win32/service'
require 'win32/shortcut'
require 'Win32API'
require 'win32ole'
require 'nkf'
include Win32

wsh = WIN32OLE.new('WScript.Shell')
wsh.Popup(NKF.nkf("-s", "デスクトップブックマークをインストールします．"),0,NKF.nkf("-w", "確認"))

#if Service.exists?("DesktopBookmark")
#  Service.delete "DesktopBookmark"
#end

# mongrel_serviceの作成
current = Dir.pwd.gsub(/\//, "\\")
#if not `which.bat mongrel_service`
#  `mongrel_rails service::install -N "DesktopBookmark" -c #{current} -p 3000 -e production`
#  Service.delete "DesktopBookmark"
#end

# デスクトップブックマークをサービスに登録
#rubypath = `which.bat ruby`.split("\n").first
#Service.new("DesktopBookmark", nil, 
#            { 'binary_path_name' => "\"#{File.dirname rubypath}\\mongrel_service.exe\" single -e production -p 3000 -a 0.0.0.0 -l \"log/mongrel.log\" -P \"log/mongrel.pid\" -c \"#{current}\" -t 0 -r \"public\" -n 1024",
#              'start_type'       => Service::SERVICE_AUTO_START,
#              'service_type'     => Win32::Service::WIN32_OWN_PROCESS }
#           )

# スタートアップフォルダの特定
obj1 = Win32API.new 'shell32', 'SHGetFolderPath', %w(l l l l p), 'l'
strBuff = "\0" * 200
obj1.call(0, 7, 0, 0, strBuff)
startup_path = strBuff.split(/\0/)[0]

# PrivateProxyServer起動スクリプトをスタートアップフォルダに
#s = Shortcut.new(startup_path + "\\PrivateProxyServer.lnk")
#s.description = "PrivateProxyServer"
#s.path = current + "\\Proxy.bat"
#s.show_cmd = Shortcut::SHOWNORMAL
#s.working_directory = current
#s.save
s = Shortcut.new(startup_path + "\\DesktopBookmark.lnk")
s.description = "DTB起動アプリケーション"
s.path = current + "\\DTBstart.exe"
s.show_cmd = Shortcut::SHOWNORMAL
s.working_directory = current
s.save

wsh.Popup(NKF.nkf("-s", "デスクトップブックマークをインストールしました．\nこれからデータベースファイルの作成を行います"),0,NKF.nkf("-w", "確認"))

# マイグレーション
`copy config\\database.yml.sample config\\database.yml`
`rake db:migrate RAILS_ENV=production`

wsh.Popup(NKF.nkf("-s", "インストール作業は全て完了しました"),0,NKF.nkf("-w", "確認"))

# デスクトップブックマークの起動
#Service.start "DesktopBookmark"
#`Proxy.bat`
Thread.new do
  `DTBstart.exe`
end
