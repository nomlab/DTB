﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
// 追加分
using System.Diagnostics;
using System.Threading;

namespace DTBstart
{
    public partial class Form1 : Form
    {     
        static public int X = 0;
        static public int Y = 0;

        //delegate void TextBoxDeligate(string str);

        public Form1()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;  // タスクバーにアイコンを表示しない

            this.dtbstart();
            this.proxystart();
            this.start();
        }

        public void dtbstart()
        {
            Process p;
            ProcessStartInfo psi = new ProcessStartInfo();

            // 起動ディレクトリを設定する
            psi.WorkingDirectory = Environment.CurrentDirectory;
            // 起動するアプリケーションを設定する
            psi.FileName = @"C:\ruby-1.8.7\bin\ruby";
            // コマンドライン引数を設定する
            psi.Arguments = @"script\server -p 3000 -e production";
            // 新しいウィンドウを作成するかどうかを設定する
            psi.CreateNoWindow = true;
            //psi.RedirectStandardOutput = true;
            // シェルを使用するかどうか設定する
            psi.UseShellExecute = false;
            // エラーダイアログを表示するのに必要な親ハンドルを設定する
            psi.ErrorDialogParentHandle = this.Handle;
            psi.ErrorDialog = true;
            // ウィンドウを非表示にする
            psi.WindowStyle = ProcessWindowStyle.Hidden;

            p = Process.Start(psi);
            X = p.Id;

            ProcessStartInfo psi2 = new ProcessStartInfo();

            // 起動ディレクトリを設定する
            psi2.WorkingDirectory = Environment.CurrentDirectory;
            // 起動するアプリケーションを設定する
            psi2.FileName = @"C:\ruby-1.8.7\bin\ruby";
            // コマンドライン引数を設定する
            psi2.Arguments = @"lib\init.rb";
            // 新しいウィンドウを作成するかどうかを設定する
            psi2.CreateNoWindow = true;
            //psi.RedirectStandardOutput = true;
            // シェルを使用するかどうか設定する
            psi2.UseShellExecute = false;
            // エラーダイアログを表示するのに必要な親ハンドルを設定する
            psi2.ErrorDialogParentHandle = this.Handle;
            psi2.ErrorDialog = true;
            // ウィンドウを非表示にする
            psi2.WindowStyle = ProcessWindowStyle.Hidden;

            Process.Start(psi2);
        }

        public void proxystart()
        {
            Process p2;
            ProcessStartInfo psi2 = new ProcessStartInfo();

            // 起動ディレクトリを設定する
            psi2.WorkingDirectory = Environment.CurrentDirectory;
            // 起動するアプリケーションを設定する
            psi2.FileName = @"C:\ruby-1.8.7\bin\ruby";
            // コマンドライン引数を設定する
            psi2.Arguments = @"PrivateProxyServer.rb";
            // 新しいウィンドウを作成するかどうかを設定する
            psi2.CreateNoWindow = true;
            //psi.RedirectStandardOutput = true;
            // シェルを使用するかどうか設定する
            psi2.UseShellExecute = false;
            // エラーダイアログを表示するのに必要な親ハンドルを設定する
            psi2.ErrorDialogParentHandle = this.Handle;
            psi2.ErrorDialog = true;
            // ウィンドウを非表示にする
            psi2.WindowStyle = ProcessWindowStyle.Hidden;

            p2 = Process.Start(psi2);
            Y = p2.Id;
        }

        public void start()
        {
            String result = "";
            //while (true)
            //{
                //Thread.Sleep(5000);
                if (X != 0)
                {
                    result += "デスクトップブックマーク：起動中\n";
                }
                else
                {
                    result += "デスクトップブックマーク：未起動\n";
                }

                if (Y != 0)
                {
                    result += "Private Proxy Server：起動中\n";
                }
                else
                {
                    result += "Private Proxy Server：未起動\n";
                }
                //TextBoxDeligate tDeligate = new TextBoxDeligate(text_change);
                //this.Invoke(tDeligate, new object[] { result });
                this.text_change(result);
            //}
        }

        private void text_change(string str)
        {
            textBox1.AppendText(str + "\n");
        }

        private void Form1_Closed(object sender, System.EventArgs e)
        {
            // 終了時、「すぐに」アイコンを消す (念のため)
            this.notifyIcon1.Visible = false;
            if (X != 0)
            {
                Process hProcess = Process.GetProcessById(X);
                hProcess.Kill();
            }
            if (Y != 0)
            {
                Process hProcess = Process.GetProcessById(Y);
                hProcess.Kill();
            }
        }

        protected override void WndProc(ref Message m)
        {
            // Form の「最小化ボタン」のクリックで、Form を Hide
            const int WM_SYSCOMMAND = 0x0112;  // システムコマンド
            const int SC_MINIMIZE = 0xf020;  // ウィンドウ最小化
            if ((m.Msg == WM_SYSCOMMAND) &&
                (((int)m.WParam & 0xfff0) == SC_MINIMIZE))
            {
                //「最小化」メッセージなら、Hide
                this.Hide();
            }
            else
            {
                base.WndProc(ref m);
            }
        }

        private void notifyIcon1_Click(object sender, System.EventArgs e)
        {
            // タスクトレイの「アイコン」のクリックで、Form を Show
            this.Show();
        }

        private void EndToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void End2ToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (X == 0)
            {
                this.dtbstart();
            }
            else
            {
                this.text_change("既にデスクトップブックマークは起動しています");
            }
            this.start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (X != 0)
            {
                Process hProcess = Process.GetProcessById(X);
                hProcess.Kill();
            }
            else
            {
                this.text_change("デスクトップブックマークは起動していません");
            }
            X = 0;

            this.start();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Y == 0)
            {
                this.proxystart();
            }
            else
            {
                this.text_change("既にProxyサーバは起動しています");
            }
            this.start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Y != 0)
            {
                Process hProcess = Process.GetProcessById(Y);
                hProcess.Kill();
            }
            else
            {
                this.text_change("Proxyサーバは起動していません");
            }
            Y = 0;

            this.start();
        }

        private void ShowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
        }
    }
}
